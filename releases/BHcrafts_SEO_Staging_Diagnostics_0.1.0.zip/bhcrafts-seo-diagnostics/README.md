# BHcrafts SEO Staging Diagnostics 0.1.0

Prepared 10 November 2026, Europe/Sarajevo.

This small diagnostics plugin reports the installed versions needed for the SEO Work Bridge. It is separate from the future content-writing integration.

## Intended site

https://stg-bhcraftsshop-affiliate.kinsta.cloud/

The report and admin page reject requests unless both WordPress Home and Site URLs use HTTPS on this exact host. A mixed live/staging URL configuration is rejected. The plugin does not change either URL. Installation or activation on live is outside this delivery's scope.

## Staging use

1. In the staging WordPress admin, open Plugins > Add New Plugin > Upload Plugin.
2. Upload BHcrafts_SEO_Staging_Diagnostics_0.1.0.zip and install it.
3. Activate BHcrafts SEO Staging Diagnostics on staging.
4. Open Tools > BHcrafts SEO Diagnostics.
5. Select Download diagnostics JSON.
6. Attach BHcrafts_Staging_Diagnostics.json in the existing Work chat.
7. Deactivate the diagnostics plugin after collecting the report if desired.

No credential entry or new API account is required for this manual export. WordPress installation/activation changes the staging plugin state. No installation or activation has been performed by this cloud task.

## Report fields

- WordPress and PHP versions.
- Home, Site and REST URLs for the designated staging site.
- WordPress environment type and search-visibility setting.
- Current theme and parent-theme versions.
- Standard WooCommerce, Yoast SEO and Yoast Premium plugin entry-file versions and active flags.
- Application Password availability, without passwords or usernames.
- Explicit indicators for areas not yet verified.

If a plugin uses a nonstandard entry file, the report records that its standard path was not found. This does not prove the plugin is absent.

## Access and behavior

The Tools page and export require manage_options. The export requires a POST request and a valid WordPress nonce. The plugin registers no unauthenticated export, content REST route, activation job, scheduled job or remote HTTP request.

The code performs no explicit product, attachment, option or database writes. It does not read product content, orders, customers, application-password records, API keys, arbitrary options or full plugin settings. WordPress itself still handles normal authentication and caching.

The report does not prove that Yoast Premium fields round-trip correctly. It does not connect Work to WordPress, inspect photographs, verify backups, isolate staging's payment/email integrations or authorize changes.

## Validation

PHP 8.4.27 syntax checks passed for both PHP files. Twenty-seven isolated checks passed, including staging-host restrictions, mixed-environment rejection, capability checks, request-method checks, nonce rejection and report-field filtering. The authorized download handler also returned valid JSON in an isolated fixture run.

Full WordPress/staging execution remains untested until the package is installed on staging. PHP 7.4 is the declared minimum based on syntax used, not a tested runtime in this delivery.

The CLI-only test file is included for review. Run it with PHP from the plugin folder:

```bash
php -n tests/security-test.php
php -n tests/security-test.php export
```

## Official references

- https://developer.wordpress.org/reference/functions/get_plugins/
- https://developer.wordpress.org/reference/functions/current_user_can/
- https://developer.wordpress.org/reference/functions/check_admin_referer/
- https://developer.wordpress.org/reference/hooks/admin_post_action/
