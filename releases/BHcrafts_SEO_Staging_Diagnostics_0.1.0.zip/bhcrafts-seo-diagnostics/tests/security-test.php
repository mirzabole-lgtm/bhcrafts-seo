<?php
if ( PHP_SAPI !== 'cli' ) { exit; }
// Isolated policy tests. These stubs do not boot WordPress or touch a database.
define( 'ABSPATH', __DIR__ . '/fake-wordpress/' );
class TestDenied extends RuntimeException {}
$GLOBALS['allowed'] = true;
$GLOBALS['home'] = 'https://stg-bhcraftsshop-affiliate.kinsta.cloud/';
$GLOBALS['site'] = $GLOBALS['home'];
$GLOBALS['nonce_valid'] = true;
$GLOBALS['hooks'] = array();
$GLOBALS['tests'] = 0;
function current_user_can( $cap ) { return 'manage_options' === $cap && $GLOBALS['allowed']; }
function home_url( $p = '' ) { return $GLOBALS['home']; }
function site_url( $p = '' ) { return $GLOBALS['site']; }
function wp_parse_url( $url ) { return parse_url( $url ); }
function wp_die( $message, $title = '', $args = array() ) { throw new TestDenied( $message, isset( $args['response'] ) ? $args['response'] : 403 ); }
function add_action( $hook, $callback ) { $GLOBALS['hooks'][ $hook ] = $callback; }
function get_plugins() {
    return array(
        'woocommerce/woocommerce.php' => array( 'Version' => '11.1.2' ),
        'wordpress-seo/wp-seo.php' => array( 'Version' => '99.0-fixture' ),
        'wordpress-seo-premium/wp-seo-premium.php' => array( 'Version' => '99.0-premium-fixture' ),
        'unrelated/private.php' => array( 'Version' => 'SECRET-SENTINEL' ),
    );
}
function is_plugin_active( $file ) { return true; }
class ThemeFixture {
    function parent() { return false; }
    function get_stylesheet() { return 'flatsome'; }
    function get_template() { return 'flatsome'; }
    function get( $field ) { return '3.20.11'; }
}
function wp_get_theme() { return new ThemeFixture(); }
function rest_url() { return $GLOBALS['home'] . 'wp-json/'; }
function wp_get_environment_type() { return 'staging'; }
function get_bloginfo( $field ) { return '6.0-fixture'; }
function is_multisite() { return false; }
function get_option( $name ) {
    if ( 'blog_public' !== $name ) { throw new RuntimeException( 'Unexpected option read: ' . $name ); }
    return '0';
}
function wp_is_application_passwords_available() { return true; }
function wp_json_encode( $value, $flags = 0 ) { return json_encode( $value, $flags ); }
function nocache_headers() {}
function check_admin_referer( $action ) {
    if ( ! $GLOBALS['nonce_valid'] ) { throw new TestDenied( 'Invalid nonce', 403 ); }
    return 1;
}
require dirname( __DIR__ ) . '/bhcrafts-seo-diagnostics.php';
function check( $condition, $label ) {
    if ( ! $condition ) { throw new RuntimeException( 'FAIL: ' . $label ); }
    ++$GLOBALS['tests'];
}
function denies( $callback, $status, $label ) {
    try { $callback(); } catch ( TestDenied $e ) { check( $e->getCode() === $status, $label ); return; }
    throw new RuntimeException( 'FAIL: expected denial for ' . $label );
}
$ns = 'BHcrafts\\SEO\\Diagnostics\\';
foreach ( $GLOBALS['hooks'] as $callback ) { check( is_callable( $callback ), 'registered callback resolves' ); }
check( count( $GLOBALS['hooks'] ) === 2, 'only admin menu and authenticated export hooks registered' );
check( ! isset( $GLOBALS['hooks']['admin_post_nopriv_bhcrafts_seo_staging_diagnostics_export'] ), 'no anonymous export hook' );
check( ($ns . 'is_designated_staging')(), 'designated staging accepted' );
$original = $GLOBALS['home'];
foreach ( array('https://bhcrafts.shop/', 'https://stg-bhcraftsshop-affiliate.kinsta.cloud.evil.test/', 'http://stg-bhcraftsshop-affiliate.kinsta.cloud/', 'https://user:password@stg-bhcraftsshop-affiliate.kinsta.cloud/', 'https://stg-bhcraftsshop-affiliate.kinsta.cloud:444/') as $bad ) {
    $GLOBALS['home'] = $bad;
    check( ! ($ns . 'is_designated_staging')(), 'reject wrong host, scheme, credentials or port' );
    denies( $ns . 'collect_report', 403, 'deny report on wrong environment' );
}
$GLOBALS['home'] = $original;
$GLOBALS['site'] = 'https://bhcrafts.shop/';
check( ! ($ns . 'is_designated_staging')(), 'mixed live/staging URL rejected' );
$GLOBALS['site'] = $original;
$GLOBALS['allowed'] = false;
denies( $ns . 'collect_report', 403, 'deny non-admin report' );
denies( $ns . 'render_tools_page', 403, 'deny non-admin page' );
denies( $ns . 'download_report', 403, 'deny non-admin download' );
$GLOBALS['allowed'] = true;
$_SERVER['REQUEST_METHOD'] = 'GET';
denies( $ns . 'download_report', 405, 'deny GET download' );
$_SERVER['REQUEST_METHOD'] = 'POST';
$GLOBALS['nonce_valid'] = false;
denies( $ns . 'download_report', 403, 'deny invalid nonce' );
$GLOBALS['nonce_valid'] = true;
$report = ($ns . 'collect_report')();
check( array_keys( $report ) === array('report_schema','diagnostics_plugin_version','generated_at_utc','mode','environment','theme','plugins','authentication','coverage'), 'fixed top-level report fields' );
check( count( $report['plugins'] ) === 3, 'only allowlisted plugins exported' );
check( strpos( json_encode( $report ), 'SECRET-SENTINEL' ) === false, 'unrelated plugin data excluded' );
check( false === $report['coverage']['yoast_premium_storage_verified'], 'unverified Yoast storage labelled' );
check( false === $report['authentication']['cloud_authenticated_connection_tested'], 'connection not fabricated' );
$source = file_get_contents( dirname( __DIR__ ) . '/bhcrafts-seo-diagnostics.php' );
check( ! preg_match('/\\b(update_option|add_option|delete_option|wp_update_post|wp_insert_post|update_post_meta|delete_post_meta|wp_remote_get|wp_remote_post|wp_remote_request|register_rest_route|register_activation_hook)\\s*\\(/', $source), 'no persistence, HTTP, custom REST or activation callbacks' );
if ( isset( $argv[1] ) && 'export' === $argv[1] ) { ($ns . 'download_report')(); }
echo 'PASS: ' . $GLOBALS['tests'] . " checks (isolated stubs, not full WordPress integration).\n";
